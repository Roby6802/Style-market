# Style Market – progetto Android iniziale

Questa è una prima app Android nativa basata su Kotlin e Jetpack Compose.

## Cosa contiene
- Home shopping con categorie Donna, Uomo, Casa, Bambini e Accessori
- Ricerca locale nel catalogo demo
- Schede prodotto dimostrative e aggiunta al contatore carrello
- Schermata Vendi con modulo per creare una scheda prodotto
- Sezioni Preferiti e Account dimostrative

## Importante
Questa versione è un prototipo locale: non è ancora un marketplace online completo.
Non include ancora registrazione reale, database condiviso, caricamento foto su server,
ordini reali, pagamenti, rimborsi o accrediti ai venditori. I pagamenti dovranno essere
integrati lato server con un provider che supporti i marketplace (ad esempio Stripe Connect
o un'alternativa idonea), dopo aver configurato società/attività, verifica venditori,
commissioni, fiscalità, privacy e condizioni di vendita.

## Come generare l'APK
1. Su un PC installa Android Studio aggiornato.
2. Estrai la cartella `StyleMarketAndroid`.
3. Apri la cartella in Android Studio.
4. Attendi la sincronizzazione Gradle e installa gli SDK richiesti.
5. Seleziona Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio mostrerà il percorso dell'APK generato.
7. Trasferisci l'APK sul telefono Android e installalo autorizzando l'installazione da quella fonte.

Requisiti: Android Studio con JDK supportato, Android SDK 35 e connessione Internet per scaricare le dipendenze Gradle.

## Identificativo app
`it.stylemarket.app`
