package it.stylemarket.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Pink = Color(0xFFE84D83)
private val Ink = Color(0xFF202027)
private val Soft = Color(0xFFFFF2F6)

data class Product(val title: String, val category: String, val price: String, val emoji: String, val shade: Color)

private val sampleProducts = listOf(
    Product("Abito elegante", "Donna", "€ 24,90", "👗", Color(0xFFF8DCE7)),
    Product("Sneakers casual", "Uomo", "€ 39,90", "👟", Color(0xFFE2E8F4)),
    Product("Lampada moderna", "Casa", "€ 18,50", "💡", Color(0xFFF6E9D5)),
    Product("Borsa da giorno", "Donna", "€ 29,90", "👜", Color(0xFFEADFF8)),
    Product("Felpa basic", "Uomo", "€ 22,90", "🧥", Color(0xFFDDEDE7)),
    Product("Decorazione casa", "Casa", "€ 12,90", "🏺", Color(0xFFF1E5D9)),
    Product("Completo bambino", "Bambini", "€ 19,90", "🧸", Color(0xFFE5EAFB)),
    Product("Orologio", "Accessori", "€ 34,90", "⌚", Color(0xFFECECEC))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StyleMarketApp() }
    }
}

@Composable
fun StyleMarketApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var category by remember { mutableStateOf("Tutti") }
    var search by remember { mutableStateOf("") }
    var cart by remember { mutableStateOf(0) }
    var showSell by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("") }

    val categories = listOf("Tutti", "Donna", "Uomo", "Casa", "Bambini", "Accessori")
    val filtered = sampleProducts.filter {
        (category == "Tutti" || it.category == category) &&
        (search.isBlank() || it.title.contains(search, ignoreCase = true))
    }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Pink, secondary = Ink, background = Color.White, surface = Color.White)
    ) {
        Scaffold(
            containerColor = Color.White,
            topBar = {
                Column(Modifier.background(Color.White)) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("STYLE MARKET", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Ink, letterSpacing = 1.sp)
                            Text("MODA  •  CASA  •  ACCESSORI", fontSize = 9.sp, color = Pink, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        }
                        BadgedBox(badge = { if (cart > 0) Badge { Text(cart.toString()) } }) {
                            Icon(Icons.Default.ShoppingBag, "Carrello", tint = Ink, modifier = Modifier.size(27.dp))
                        }
                    }
                    OutlinedTextField(
                        value = search, onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                        placeholder = { Text("Cerca vestiti, scarpe, casa...") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Pink, unfocusedBorderColor = Color(0xFFE7E2E5)
                        )
                    )
                    Spacer(Modifier.height(10.dp))
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0; showSell = false }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1; showSell = false }, icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("Preferiti") })
                    NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2; showSell = true }, icon = { Icon(Icons.Default.AddCircle, null) }, label = { Text("Vendi") })
                    NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3; showSell = false }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Account") })
                }
            }
        ) { padding ->
            if (showSell) {
                SellScreen(Modifier.padding(padding), onPublish = {
                    notice = "Scheda prodotto salvata in modalità demo. Per pubblicarla online servirà il backend."
                    showSell = false; selectedTab = 0
                })
            } else {
                Column(Modifier.padding(padding)) {
                    if (selectedTab == 0) {
                        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                            Box(
                                Modifier.fillMaxWidth().background(Soft, RoundedCornerShape(18.dp)).padding(18.dp)
                            ) {
                                Column {
                                    Text("IL TUO STILE,", fontSize = 12.sp, color = Pink, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                    Text("A PORTATA DI CLICK", fontSize = 22.sp, color = Ink, fontWeight = FontWeight.Black)
                                    Text("Scopri le novità e le offerte del marketplace", fontSize = 12.sp, color = Ink)
                                    Spacer(Modifier.height(8.dp))
                                    Text("NUOVI ARRIVI  •  OFFERTE OGNI GIORNO", fontSize = 9.sp, color = Pink, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Text("CATEGORIE", fontWeight = FontWeight.Bold, color = Ink, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(categories) { item ->
                                    FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item) })
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Scelti per te", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
                                Text("${filtered.size} prodotti", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(2),
                            contentPadding = PaddingValues(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filtered) { product ->
                                ProductCard(product, onAdd = { cart++ ; notice = "${product.title} aggiunto al carrello" })
                            }
                        }
                    } else {
                        EmptySection(
                            title = if (selectedTab == 1) "I tuoi preferiti" else "Il tuo account",
                            body = if (selectedTab == 1) "Salva qui i prodotti che ti piacciono." else "Accedi o registrati per gestire ordini e acquisti.",
                            icon = if (selectedTab == 1) Icons.Default.FavoriteBorder else Icons.Default.PersonOutline
                        )
                    }
                }
            }
        }
        if (notice.isNotBlank()) {
            LaunchedEffect(notice) { kotlinx.coroutines.delay(2300); notice = "" }
            SnackbarHost(hostState = remember { SnackbarHostState() }, modifier = Modifier.padding(bottom = 76.dp)) {
                Snackbar { Text(notice) }
            }
        }
    }
}

@Composable
fun ProductCard(product: Product, onAdd: () -> Unit) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Column {
            Box(Modifier.fillMaxWidth().height(132.dp).background(product.shade), contentAlignment = Alignment.Center) {
                Text(product.emoji, fontSize = 58.sp)
                Surface(Modifier.align(Alignment.TopStart).padding(8.dp), color = Color.White, shape = RoundedCornerShape(6.dp)) {
                    Text("NOVITÀ", Modifier.padding(horizontal = 7.dp, vertical = 4.dp), fontSize = 8.sp, color = Pink, fontWeight = FontWeight.Bold)
                }
            }
            Column(Modifier.padding(10.dp)) {
                Text(product.category.uppercase(), fontSize = 9.sp, color = Pink, fontWeight = FontWeight.Bold)
                Text(product.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Ink, maxLines = 1)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text(product.price, fontWeight = FontWeight.Black, fontSize = 14.sp, color = Ink)
                    IconButton(onClick = onAdd, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.AddShoppingCart, "Aggiungi al carrello", tint = Pink)
                    }
                }
            }
        }
    }
}

@Composable
fun SellScreen(modifier: Modifier, onPublish: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Donna") }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Vendi su Style Market", fontSize = 23.sp, fontWeight = FontWeight.Black, color = Ink)
        Text("Crea la scheda del tuo prodotto. In questa prima demo i dati non vengono ancora pubblicati online.", fontSize = 13.sp, color = Color.Gray)
        OutlinedTextField(title, { title = it }, label = { Text("Nome prodotto") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(price, { price = it }, label = { Text("Prezzo in euro") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(description, { description = it }, label = { Text("Descrizione") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Text("Categoria", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Donna", "Uomo", "Casa", "Bambini").forEach {
                FilterChip(selected = category == it, onClick = { category = it }, label = { Text(it) })
            }
        }
        Button(onClick = onPublish, enabled = title.isNotBlank() && price.isNotBlank(), modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Pink)) {
            Icon(Icons.Default.Publish, null); Spacer(Modifier.width(8.dp)); Text("Salva prodotto")
        }
    }
}

@Composable
fun EmptySection(title: String, body: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = Pink, modifier = Modifier.size(54.dp))
        Spacer(Modifier.height(12.dp))
        Text(title, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(body, color = Color.Gray, fontSize = 13.sp)
    }
}
